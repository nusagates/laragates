<template>
  <div class="min-h-screen flex items-center justify-center bg-gray-100">

    <div class="w-full max-w-md bg-white shadow-lg rounded-xl p-8">
      <div class="text-center mb-6">
        <h1 class="text-2xl font-bold text-gray-700">Laragates</h1>
        <p class="text-gray-500 text-sm">
          Welcome to your new application
        </p>
      </div>

      <slot />
    </div>

  </div>
</template>

<script setup>
</script>
